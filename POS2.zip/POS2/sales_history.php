<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$sql = "SELECT * FROM sales ORDER BY sale_id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Sales History</title>
   <title>Sales History</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Sales History</h1>
        <table>…</table>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
    <div class="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>
    <div class="main-content">
        <h1>Sales History</h1>
        <table>
            <thead>
                <tr>
                    <th>Sale ID</th>
                    <th>Total</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['sale_id'] ?></td>
                    <td>$<?= number_format($row['total_amount'],2) ?></td>
                    <td><?= $row['created_at'] ?></td>
                    <td>
                        <a href="view_receipt.php?sale_id=<?= $row['sale_id'] ?>"
                           class="view-btn">View Receipt</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
