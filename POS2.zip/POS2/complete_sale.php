<?php
// complete_sale.php
session_start();
include('db.php');
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_POST['submit_sale'], $_POST['items'], $_POST['quantities'])) {
    header('Location: sales.php');
    exit;
}

// Begin transaction
$conn->begin_transaction();
try {
    $total = 0;

    // 1) Create master sale record (sales table)
    $stmtSale = $conn->prepare("INSERT INTO sales (total_amount, created_at) VALUES (0, NOW())");
    if (!$stmtSale) {
        throw new Exception('Prepare failed (stmtSale): ' . $conn->error);
    }
    $stmtSale->execute();
    $sale_id = $conn->insert_id;
    $stmtSale->close();

    // 2) Prepare detail and history inserts
    $stmtItem   = $conn->prepare("SELECT item_name, price, quantity FROM storage WHERE item_id = ? FOR UPDATE");
    if (!$stmtItem) {
        throw new Exception('Prepare failed (stmtItem): ' . $conn->error);
    }

    $stmtDetail = $conn->prepare("INSERT INTO sale_items (sale_id, item_name, quantity, subtotal) VALUES (?, ?, ?, ?)");
    if (!$stmtDetail) {
        throw new Exception('Prepare failed (stmtDetail): ' . $conn->error);
    }

    $stmtHist   = $conn->prepare("INSERT INTO sales_history (item_id, item_name, qty_sold, price, subtotal, cashier, sale_date) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    if (!$stmtHist) {
        throw new Exception('Prepare failed (stmtHist): ' . $conn->error);
    }

    $stmtUpdate = $conn->prepare("UPDATE storage SET quantity = quantity - ? WHERE item_id = ?");
    if (!$stmtUpdate) {
        throw new Exception('Prepare failed (stmtUpdate): ' . $conn->error);
    }

    // 3) Loop each selected item
    foreach ($_POST['items'] as $itemId) {
        $qty = isset($_POST['quantities'][$itemId])
             ? (int)$_POST['quantities'][$itemId]
             : 0;
        if ($qty < 1) continue;

        // Lock & fetch
        $stmtItem->bind_param('s', $itemId);
        $stmtItem->execute();
        $res = $stmtItem->get_result();
        if (!$row = $res->fetch_assoc()) continue;
        if ($row['quantity'] < $qty) continue;

        $price    = (float)$row['price'];
        $subtotal = $price * $qty;
        $total   += $subtotal;

        // Insert sale_items
        $stmtDetail->bind_param('isid', $sale_id, $row['item_name'], $qty, $subtotal);
        $stmtDetail->execute();

        // Insert sales_history
        $stmtHist->bind_param(
            'ssidds',
            $itemId,
            $row['item_name'],
            $qty,
            $price,
            $subtotal,
            $_SESSION['username']
        );
        $stmtHist->execute();

        // Update stock
        $stmtUpdate->bind_param('is', $qty, $itemId);
        $stmtUpdate->execute();
    }

    // 4) Update total in sales master
    $stmtUpdTotal = $conn->prepare("UPDATE sales SET total_amount = ? WHERE sale_id = ?");
    if (!$stmtUpdTotal) {
        throw new Exception('Prepare failed (stmtUpdTotal): ' . $conn->error);
    }
    $stmtUpdTotal->bind_param('di', $total, $sale_id);
    $stmtUpdTotal->execute();
    $stmtUpdTotal->close();

    // 5) Commit & redirect
    $conn->commit();
    header("Location: view_receipt.php?sale_id=$sale_id");
    exit;

} catch (Exception $e) {
    $conn->rollback();
    die("Transaction failed: " . $e->getMessage());
}