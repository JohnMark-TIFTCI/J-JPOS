<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="sidebar">
    <?php include 'sidebar.php'; ?>
  </div>

  <div class="main-content">
    <h1>Welcome, <?= htmlspecialchars($_SESSION['username']) ?>!</h1>
    <div class="dashboard-grid">
      <div class="dashboard-card" onclick="location.href='sales.php'">
        <h2>New Sale</h2>
        <p>Start a transaction</p>
      </div>
      <div class="dashboard-card" onclick="location.href='sales_history.php'">
        <h2>Sales History</h2>
        <p>View past transactions</p>
      </div>
      <div class="dashboard-card" onclick="location.href='storage.php'">
        <h2>Inventory</h2>
        <p>Manage stock</p>
      </div>
      <div class="dashboard-card" onclick="location.href='logout.php'">
        <h2>Logout</h2>
        <p>End your session</p>
      </div>
    </div>
  </div>
</body>
</html>
