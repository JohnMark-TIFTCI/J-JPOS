<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Handle Add Item form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    $item_id = trim($_POST['item_id']);
    $item_name = trim($_POST['item_name']);
    $quantity = intval($_POST['quantity']);
    $price = floatval($_POST['price']);

    // Check for unique item_id and item_name
    $stmt = $conn->prepare("SELECT COUNT(*) FROM storage WHERE item_id = ? OR item_name = ?");
    $stmt->bind_param('ss', $item_id, $item_name);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        echo "<script>alert('Item ID or Name already exists.');</script>";
    } else {
        $stmt = $conn->prepare("INSERT INTO storage (item_id, item_name, quantity, price) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssid', $item_id, $item_name, $quantity, $price);
        if ($stmt->execute()) {
            echo "<script>alert('Item added successfully.'); window.location.href='storage.php';</script>";
        } else {
            echo "<script>alert('Error adding item.');</script>";
        }
        $stmt->close();
    }
}

// Handle Delete Item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_item'])) {
    $del_id = $_POST['delete_item'];
    $stmt = $conn->prepare("DELETE FROM storage WHERE item_id = ?");
    $stmt->bind_param('s', $del_id);
    $stmt->execute();
    $stmt->close();
    header('Location: storage.php');
    exit;
}

// Handle Reduce Stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reduce_stock'])) {
    $item_id = $_POST['item_id'];
    $reduce_qty = intval($_POST['reduce_quantity']);

    $stmt = $conn->prepare("UPDATE storage SET quantity = quantity - ? WHERE item_id = ? AND quantity >= ?");
    $stmt->bind_param('isi', $reduce_qty, $item_id, $reduce_qty);
    $stmt->execute();
    $stmt->close();
    header('Location: storage.php');
    exit;
}

// Handle Add Stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_stock'])) {
    $item_id = $_POST['item_id'];
    $add_qty = intval($_POST['add_quantity']);

    $stmt = $conn->prepare("UPDATE storage SET quantity = quantity + ? WHERE item_id = ?");
    $stmt->bind_param('is', $add_qty, $item_id);
    $stmt->execute();
    $stmt->close();
    header('Location: storage.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Inventory</title>
  <link rel="stylesheet" href="style.css">
  <style>
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.4);
    }

    .modal-content {
      background-color: #fefefe;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 400px;
      border-radius: 5px;
    }

    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
    }

    .close:hover,
    .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
    }

    .btn-primary {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      cursor: pointer;
      border-radius: 4px;
    }

    .btn-primary:hover {
      background-color: #45a049;
    }

    .btn-reduce {
      background-color: #f44336;
      color: white;
      padding: 5px 10px;
      border: none;
      cursor: pointer;
      border-radius: 4px;
    }

    .btn-reduce:hover {
      background-color: #da190b;
    }

    .btn-add {
      background-color: #008CBA;
      color: white;
      padding: 5px 10px;
      border: none;
      cursor: pointer;
      border-radius: 4px;
    }

    .btn-add:hover {
      background-color: #007bb5;
    }

    .adjust-form {
      display: none;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <?php include 'sidebar.php'; ?>
  </div>
  <div class="main-content">
    <h1>Inventory Management</h1>
    <button id="addItemBtn" class="btn-primary">Add Item</button>

    <!-- Add Item Modal -->
    <div id="addItemModal" class="modal">
      <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Add New Item</h2>
        <form method="POST" action="storage.php">
          <label for="item_id">Item ID:</label>
          <input type="text" name="item_id" required>

          <label for="item_name">Item Name:</label>
          <input type="text" name="item_name" required>

          <label for="quantity">Quantity:</label>
          <input type="number" name="quantity" min="1" required>

          <label for="price">Price:</label>
          <input type="number" name="price" step="0.01" min="0" required>

          <button type="submit" name="add_item" class="btn-primary">Add Item</button>
        </form>
      </div>
    </div>

    <h2>Current Inventory</h2>
    <table>
      <thead>
        <tr>
          <th>Item ID</th>
          <th>Item Name</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result = $conn->query("SELECT * FROM storage");
        while ($row = $result->fetch_assoc()):
        ?>
        <tr>
          <td><?= htmlspecialchars($row['item_id']) ?></td>
          <td><?= htmlspecialchars($row['item_name']) ?></td>
          <td><?= (int)$row['quantity'] ?></td>
          <td>$<?= number_format($row['price'],2) ?></td>
          <td>
            <!-- Reduce button -->
            <button class="btn-reduce" onclick="toggleForm('reduce-form-<?= $row['item_id'] ?>')">Reduce</button>

            <!-- Add button -->
            <button class="btn-add" onclick="toggleForm('add-form-<?= $row['item_id'] ?>')">Add</button>

            <!-- Delete button -->
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete <?= addslashes($row['item_name']) ?>?');">
              <input type="hidden" name="delete_item" value="<?= htmlspecialchars($row['item_id']) ?>">
              <button class="btn-reduce">Delete</button>
            </form>
          </td>
        </tr>
        <!-- Reduce Form -->
        <tr id="reduce-form-<?= $row['item_id'] ?>" class="adjust-form">
          <td colspan="5">
            <form method="POST">
              <input type="hidden" name="item_id" value="<?= htmlspecialchars($row['item_id']) ?>">
              <label for="reduce_quantity">Reduce Quantity:</label>
              <input type="number" name="reduce_quantity" min="1" max="<?= (int)$row['quantity'] ?>" required>
              <button type="submit" name="reduce_stock" class="btn-reduce">Confirm</button>
            </form>
          </td>
        </tr>
        <!-- Add Form -->
        <tr id="add-form-<?= $row['item_id'] ?>" class="adjust-form">
          <td colspan="5">
            <form method="POST">
              <input type="hidden" name="item_id" value="<?= htmlspecialchars($row['item_id']) ?>">
              <label for="add_quantity">Add Quantity:</label>
              <input type="number" name="add_quantity" min="1" required>
              <button type="submit" name="add_stock" class="btn-add">Confirm</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <script>
    // Modal functionality
    var modal = document.getElementById("addItemModal");
    var btn = document.getElementById("addItemBtn");
    var span = document.getElementsByClassName("close")[0];

    btn.onclick = function() {
      modal.style.display = "block";
    }

    span.onclick = function() {
      modal.style.display = "none";
    }

    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }

    // Toggle adjust form
    function toggleForm(id) {
      const row = document.getElementById(id);
      row.style.display = row.style.display === 'table-row' ? 'none' : 'table-row';
    }
  </script>
</body>
</html>
