<?php
// sales.php
session_start();
include('db.php');
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>New Sale</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="sidebar">
    <?php include 'sidebar.php'; ?>
  </div>
  <div class="main-content pos-grid">
    <div class="products-table">
      <h1>New Transaction</h1>
      <form method="POST" action="complete_sale.php" id="sale-form">
        <table>
          <thead>
            <tr>
              <th>Select</th>
              <th>Item</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Qty</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $stmt = $conn->prepare("SELECT item_id, item_name, price, quantity FROM storage");
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()):
              $id = htmlspecialchars($row['item_id']);
              $price = number_format($row['price'], 2);
              $quantity = (int)$row['quantity'];
            ?>
              <tr>
                <td><input type="checkbox" name="items[]" value="<?= $id ?>" onchange="toggleQty(this)"></td>
                <td><?= htmlspecialchars($row['item_name']) ?></td>
                <td>$<?= $price ?></td>
                <td><?= $quantity ?></td>
                <td><input type="number" name="quantities[<?= $id ?>]" min="1" max="<?= $quantity ?>" value="1" disabled onchange="updateSummary()"></td>
              </tr>
            <?php endwhile; $stmt->close(); ?>
          </tbody>
        </table>
      </form>
    </div>
    <div class="cart-summary">
      <h3>Transaction Summary</h3>
      <div id="cart-items">No items selected</div>
      <hr>
      <div class="total-section">
        <strong>Total:</strong>
        <span id="cart-total">$0.00</span>
      </div>
      <button type="submit" form="sale-form" name="submit_sale" class="btn-primary" style="width:100%; margin-top:1rem;">Complete Sale</button>
    </div>
  </div>
  <script>
    // Store prices in a JavaScript object for accurate calculations
    const prices = {};
    <?php
    $stmt = $conn->prepare("SELECT item_id, price FROM storage");
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()):
      $id = htmlspecialchars($row['item_id']);
      $price = $row['price'];
    ?>
      prices["<?= $id ?>"] = <?= $price ?>;
    <?php endwhile; $stmt->close(); ?>

    function toggleQty(checkbox) {
      const row = checkbox.closest('tr');
      const qtyInput = row.querySelector('input[type="number"]');
      qtyInput.disabled = !checkbox.checked;
      if (!checkbox.checked) qtyInput.value = 1;
      updateSummary();
    }

    function updateSummary() {
      const rows = document.querySelectorAll('tbody tr');
      let total = 0;
      let items = [];

      rows.forEach(row => {
        const cb = row.querySelector('input[type="checkbox"]');
        const qtyInput = row.querySelector('input[type="number"]');
        if (cb && cb.checked) {
          const id = cb.value;
          const name = row.cells[1].textContent;
          const price = prices[id];
          const qty = parseInt(qtyInput.value) || 0;
          const subtotal = price * qty;
          total += subtotal;
          items.push({ name, qty, subtotal });
        }
      });

      const container = document.getElementById('cart-items');
      if (items.length === 0) {
        container.textContent = 'No items selected';
      } else {
        container.innerHTML = '';
        items.forEach(item => {
          const div = document.createElement('div');
          div.style.display = 'flex';
          div.style.justifyContent = 'space-between';
          div.style.margin = '0.5rem 0';
          div.textContent = `${item.name} x${item.qty}: $${item.subtotal.toFixed(2)}`;
          container.appendChild(div);
        });
      }
      document.getElementById('cart-total').textContent = '$' + total.toFixed(2);
    }
  </script>
</body>
</html>
