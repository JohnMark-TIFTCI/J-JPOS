<?php
include('db.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Fetch sales history
$sql = "SELECT * FROM sales ORDER BY sale_id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales History</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .view-btn {
            background-color: #4CAF50;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
        }
        .view-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Sales History</h1>
    <table>
        <tr>
            <th>Sale ID</th>
            <th>Total</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['sale_id']; ?></td>
                <td><?php echo $row['total']; ?></td>
                <td><?php echo $row['created_at']; ?></td>
                <td><a href="view_receipt.php?sale_id=<?php echo $row['sale_id']; ?>">View Receipt</a></td>
            </tr>
        <?php endwhile; ?>
    </table>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
