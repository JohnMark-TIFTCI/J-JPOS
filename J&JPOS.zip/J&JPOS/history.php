<?php
// Include database connection
include('db.php');

// Fetch Transaction Records (Using sale_date for sorting)
$sql = "SELECT * FROM sales_history ORDER BY sale_date DESC;";
$result = $conn->query($sql);

// Check for errors in the query
if (!$result) {
    die('Query failed: ' . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales History</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .view-btn {
            background-color: #4CAF50;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
        }
        .view-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Sales History</h1>
    <table>
        <tr>
            <th>Transaction ID</th>
            <th>Total Amount</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo 'RC-' . str_pad($row['sale_id'], 5, '0', STR_PAD_LEFT); ?></td>
                <td>$<?php echo number_format($row['total_amount'], 2); ?></td>
                <td><?php echo $row['sale_date']; ?></td>
                <td>
                    <a href="view_receipt.php?sale_id=<?php echo $row['sale_id']; ?>" class="view-btn">View</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
