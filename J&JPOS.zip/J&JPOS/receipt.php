<?php
session_start();

if (!isset($_SESSION['sale_items']) || !isset($_SESSION['total_amount'])) {
    echo "No items in the sale.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 10px;
            width: 300px;
            margin: auto;
        }
        .receipt {
            border: 1px solid #000;
            padding: 10px;
            font-size: 12px;
        }
        .receipt h3 {
            text-align: center;
            margin: 0;
        }
        .receipt table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }
        .receipt table, th, td {
            border: 1px solid #000;
        }
        .receipt th, .receipt td {
            padding: 5px;
            text-align: center;
        }
        .receipt .total {
            text-align: right;
        }
        .receipt .total b {
            font-size: 14px;
        }
        .footer {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="receipt">
        <h3>Store Receipt</h3>
        <table>
            <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
            <?php
            $grand_total = 0;
            foreach ($_SESSION['sale_items'] as $item) {
                $grand_total += $item['total'];
                echo "<tr>
                        <td>" . $item['item_name'] . "</td>
                        <td>" . $item['quantity'] . "</td>
                        <td>$" . number_format($item['price'], 2) . "</td>
                        <td>$" . number_format($item['total'], 2) . "</td>
                      </tr>";
            }
            ?>
        </table>
        <div class="total">
            <b>Total Amount: $<?php echo number_format($grand_total, 2); ?></b>
        </div>
        <div class="footer">
            <p>Thank you for your purchase!</p>
        </div>
    </div>

</body>
</html>
