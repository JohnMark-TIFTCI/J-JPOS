<?php
include('db.php');
// Handle form submission for updating storage
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_storage'])) {
    $item_id = $_POST['item_id']; // Ensure item_id is provided
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    // SQL query to insert or update the item in storage
    $sql = "INSERT INTO storage (item_id, item_name, quantity, price) 
            VALUES ('$item_id', '$item_name', '$quantity', '$price')
            ON DUPLICATE KEY UPDATE 
            quantity = quantity + '$quantity';";  // Update quantity if item_id already exists

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Storage updated successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Storage</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Storage</h1>
    <form method="POST">
        <input type="text" name="item_id" placeholder="Item ID" required>
        <input type="text" name="item_name" placeholder="Item Name" required>
        <input type="number" name="quantity" placeholder="Quantity" required>
        <input type="number" step="0.01" name="price" placeholder="Price" required>
        <button type="submit" name="update_storage">Update Storage</button>
    </form>

    <h2>Current Storage</h2>
    <table>
        <thead>
            <tr>
                <th>Item ID</th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch all storage items
            $result = $conn->query("SELECT * FROM storage");
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['item_id']}</td>";
                echo "<td>{$row['item_name']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "<td>{$row['price']}</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
