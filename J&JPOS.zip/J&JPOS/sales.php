<?php
session_start();
include('db.php');

// Fetch all items from storage to display in the sale form
$sql = "SELECT * FROM storage";
$result = $conn->query($sql);

// Sale processing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['make_sale'])) {
    $items = $_POST['item_name']; // Array of item names
    $quantities = $_POST['quantity']; // Array of quantities

    $sale_items = [];
    $total_amount = 0;

    // Loop through selected items and process each one
    for ($i = 0; $i < count($items); $i++) {
        $item_name = $items[$i];
        $quantity = $quantities[$i];

        // Fetch item details from storage
        $sql = "SELECT * FROM storage WHERE item_name = '$item_name';";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        if ($row['quantity'] >= $quantity) {
            $total = $quantity * $row['price'];
            $sale_items[] = [
                'item_name' => $row['item_name'],
                'quantity' => $quantity,
                'price' => $row['price'],
                'total' => $total
            ];
            $total_amount += $total;

            // Update storage quantity
            $new_quantity = $row['quantity'] - $quantity;
            $conn->query("UPDATE storage SET quantity = '$new_quantity' WHERE item_name = '$item_name'");
        } else {
            echo "<script>alert('Insufficient stock for $item_name');</script>";
        }
    }

    // Insert the sale into the database (Sales history table)
    $sale_date = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("INSERT INTO sales_history (sale_date, total_amount) VALUES (?, ?)");
    $stmt->bind_param('sd', $sale_date, $total_amount);
    $stmt->execute();
    $sale_id = $stmt->insert_id; // Get the inserted sale's ID

    // Insert sale items into the sales_items table
    foreach ($sale_items as $item) {
        $stmt = $conn->prepare("INSERT INTO sales_items (sale_id, item_name, quantity, price, total) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('isidd', $sale_id, $item['item_name'], $item['quantity'], $item['price'], $item['total']);
        $stmt->execute();
    }

    // Store sale items and total in session for the receipt
    $_SESSION['sale_items'] = $sale_items;
    $_SESSION['total_amount'] = $total_amount;

    // Redirect to receipt page
    echo "<script>window.location.href = 'receipt.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        form {
            margin: 20px;
        }
        select, input {
            margin: 10px 0;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Make a Sale</h1>
    <form method="POST">
        <div id="item-container">
            <div class="item">
                <select name="item_name[]">
                    <option value="">Select Item</option>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <option value="<?php echo $row['item_name']; ?>"><?php echo $row['item_name']; ?> - $<?php echo $row['price']; ?></option>
                    <?php endwhile; ?>
                </select>
                <input type="number" name="quantity[]" min="1" required placeholder="Quantity">
            </div>
        </div>
        <button type="button" id="add-item">Add Another Item</button>
        <button type="submit" name="make_sale">Complete Sale</button>
    </form>

    <script>
        document.getElementById('add-item').addEventListener('click', function() {
            const container = document.getElementById('item-container');
            const itemDiv = document.createElement('div');
            itemDiv.classList.add('item');
            itemDiv.innerHTML = `
                <select name="item_name[]">
                    <option value="">Select Item</option>
                    <?php
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()):
                    ?>
                        <option value="<?php echo $row['item_name']; ?>"><?php echo $row['item_name']; ?> - $<?php echo $row['price']; ?></option>
                    <?php endwhile; ?>
                </select>
                <input type="number" name="quantity[]" min="1" required placeholder="Quantity">
            `;
            container.appendChild(itemDiv);
        });
    </script>
</body>
</html>
