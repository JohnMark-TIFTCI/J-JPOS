<?php
session_start();
include('db.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Handle sales submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_sale'])) {
    $items = $_POST['items'] ?? [];
    $quantities = $_POST['quantities'] ?? [];

    if (empty($items) || empty($quantities)) {
        echo "<script>alert('Please select items and quantities');</script>";
    } else {
        $total = 0;
        $sale_items = [];

        foreach ($items as $index => $item_id) {
            $quantity = (int)$quantities[$index];

            // Retrieve item details
            $query = "SELECT item_name, price, quantity FROM storage WHERE id = '$item_id'";
            $result = $conn->query($query);

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $item_name = $row['item_name'];
                $item_price = (float)$row['price'];
                $available_quantity = (int)$row['quantity'];

                if ($quantity > $available_quantity) {
                    echo "<script>alert('Insufficient stock for $item_name');</script>";
                } else {
                    $subtotal = $item_price * $quantity;
                    $total += $subtotal;

                    // Reduce the item stock
                    $conn->query("UPDATE storage SET quantity = quantity - $quantity WHERE id = '$item_id'");

                    // Prepare sale items for insertion
                    $sale_items[] = [
                        'item_id' => $item_id,
                        'item_name' => $item_name,
                        'quantity' => $quantity,
                        'subtotal' => $subtotal
                    ];
                }
            }
        }

        // Insert into sales table
        if (!empty($sale_items)) {
            $conn->query("INSERT INTO sales (total_amount) VALUES ($total)");
            $sale_id = $conn->insert_id;

            // Insert sale items into sale_items table
            foreach ($sale_items as $sale_item) {
                $conn->query("
                    INSERT INTO sale_items (sale_id, item_id, item_name, quantity, subtotal) 
                    VALUES ('$sale_id', '{$sale_item['item_id']}', '{$sale_item['item_name']}', '{$sale_item['quantity']}', '{$sale_item['subtotal']}')
                ");
            }

            echo "<script>alert('Sale completed! Total: $$total'); window.location.href = 'receipt.php?sale_id=$sale_id';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            text-align: center;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Sales</h1>
    <form method="POST">
        <table>
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Item Name</th>
                    <th>Price</th>
                    <th>Available Quantity</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM storage";
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><input type="checkbox" name="items[]" value="<?= $row['id']; ?>"></td>
                            <td><?= htmlspecialchars($row['item_name']); ?></td>
                            <td><?= htmlspecialchars($row['price']); ?></td>
                            <td><?= htmlspecialchars($row['quantity']); ?></td>
                            <td><input type="number" name="quantities[]" min="1" max="<?= htmlspecialchars($row['quantity']); ?>" required></td>
                        </tr>
                    <?php endwhile;
                } else {
                    echo "<tr><td colspan='5'>No items available</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <button type="submit" name="submit_sale">Complete Sale</button>
    </form>
</body>
</html>
