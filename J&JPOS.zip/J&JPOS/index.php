<?php
// JM AND JEFF POINT OF SALE

// Database Connection (Update credentials as needed)
$conn = new mysqli('localhost', 'root', '', 'point_of_sale');
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

// Index Page (Login Only)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === 'admin' && $password === 'admin') {
        session_start();
        $_SESSION['username'] = $username;
        header('Location: dashboard.php');
    } else {
        echo "<script>alert('Invalid Credentials');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JM AND JEFF POS</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include modern design here -->
</head>
<body>
    <h1>Welcome to JM AND JEFF POS</h1>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>
</body>
</html>

<!-- 
-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS point_of_sale;

USE point_of_sale;

-- Table to store products in the storage
CREATE TABLE IF NOT EXISTS storage (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL,
    quantity INT DEFAULT 0,
    price DECIMAL(10, 2) NOT NULL
);

-- Table to store sales transactions
CREATE TABLE IF NOT EXISTS sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    quantity INT NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES storage(item_id)
);

-- Table to store sales history (finalized transactions)
CREATE TABLE IF NOT EXISTS sales_history (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    total_amount DECIMAL(10, 2) NOT NULL,
    sale_date DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table to store employee data (admin/employee management)
CREATE TABLE IF NOT EXISTS employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Table to store login attempts and session data (optional security)
CREATE TABLE IF NOT EXISTS sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    logout_time DATETIME
);

-- Insert some initial data into the storage (example products)
INSERT INTO storage (item_name, quantity, price) VALUES
('Monitor', 50, 150.00),
('Keyboard', 100, 30.00),
('Mouse', 200, 15.00),
('Laptop', 30, 1000.00);

-- Insert an admin user (for login purposes)
INSERT INTO employees (username, password) VALUES
('admin', 'admin'); -- Note: In a real application, use a hashed password.
-->
