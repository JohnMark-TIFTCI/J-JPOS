<?php
$servername = "localhost";
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "JJPOS"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if admin exists, if not create default admin credentials
$checkAdminQuery = "SELECT * FROM employees WHERE username = 'admin'";
$result = $conn->query($checkAdminQuery);

if ($result->num_rows == 0) {
    $defaultAdminPassword = password_hash('admin', PASSWORD_DEFAULT); // Hash 'admin'
    $createAdminQuery = "INSERT INTO employees (username, password) VALUES ('admin', '$defaultAdminPassword')";
    $conn->query($createAdminQuery);
}
?>
