<?php
// Include database connection
include('db.php');

// Check if sale_id is passed in the URL
if (isset($_GET['sale_id']) && !empty($_GET['sale_id'])) {
    $sale_id = $_GET['sale_id'];  // Get sale_id from the URL
} else {
    die("Sale ID is required. Please provide a valid sale ID.");
}

// Fetch sale details
$sql = "SELECT * FROM sales_history WHERE sale_id = '$sale_id'";
$result = $conn->query($sql);

// Check if sale exists
if ($result->num_rows > 0) {
    $sale = $result->fetch_assoc();
} else {
    die("Sale not found. Please provide a valid sale ID.");
}

// Fetch sale items
$sql_items = "SELECT * FROM sales_items WHERE sale_id = '$sale_id'";
$result_items = $conn->query($sql_items);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt View</title>
    <style>
        /* View Receipt CSS */
        body {
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 0;
        }

        .receipt-container {
            width: 280px; /* Standard receipt width */
            margin: 0 auto;
            padding: 10px;
            border: 1px solid #000;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            background-color: #fff;
            text-align: center;
        }

        .receipt-header {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .receipt-details {
            margin-bottom: 20px;
            text-align: left;
            padding-left: 10px;
            font-size: 12px;
        }

        .receipt-item {
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            font-size: 12px;
        }

        .receipt-item span {
            width: 50%;
        }

        .receipt-item .price {
            text-align: right;
        }

        .total {
            font-weight: bold;
            font-size: 14px;
            padding-top: 10px;
        }

        .receipt-footer {
            margin-top: 20px;
            font-size: 10px;
            color: #666;
        }
    </style>
</head>
<body>

<div class="receipt-container">
    <div class="receipt-header">
        <h2>JM & JEFF POS</h2>
        <p>Receipt View</p>
    </div>
    
    <div class="receipt-details">
        <p>Date: <?php echo $sale['sale_date']; ?></p>
        <p>Receipt #: <?php echo 'RC-' . str_pad($sale['sale_id'], 5, '0', STR_PAD_LEFT); ?></p>
    </div>

    <div class="receipt-items">
        <?php while ($item = $result_items->fetch_assoc()): ?>
            <div class="receipt-item">
                <span><?php echo $item['item_name']; ?> (x<?php echo $item['quantity']; ?>)</span>
                <span class="price">$<?php echo number_format($item['price'], 2); ?></span>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="total">
        Total: $<?php echo number_format($sale['total_amount'], 2); ?>
    </div>

    <div class="receipt-footer">
        <p>Thank you for shopping with us!</p>
        <p>Visit again.</p>
    </div>
</div>

</body>
</html>
