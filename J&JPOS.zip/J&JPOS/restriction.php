<?php
// Restricted Features for Employees
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$is_admin = ($_SESSION['username'] === 'admin');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restricted Access</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <nav>
        <ul>
            <?php if ($is_admin): ?>
                <li><a href="storage.php">Storage</a></li>
                <li><a href="register.php">Register</a></li>
            <?php endif; ?>
            <li><a href="sales.php">Sales</a></li>
            <li><a href="history.php">History</a></li>
            <li><a href="logout.php?logout=1">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
