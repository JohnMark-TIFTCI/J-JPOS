<?php
// Include database connection
include('db.php');

// Register Employee (Admin Only)
session_start();
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $employee_username = $_POST['employee_username'];
    $employee_password = password_hash($_POST['employee_password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO employees (username, password) VALUES ('$employee_username', '$employee_password');";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Employee registered successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Employee</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Register Employee</h1>
    <form method="POST">
        <input type="text" name="employee_username" placeholder="Username" required>
        <input type="password" name="employee_password" placeholder="Password" required>
        <button type="submit" name="register">Register</button>
    </form>
</body>
</html>
