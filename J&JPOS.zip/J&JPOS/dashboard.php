<?php
// Dashboard (Redirect if not logged in)
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Dashboard</h1>
    <nav>
        <ul>
            <li><a href="storage.php">Storage</a></li>
            <li><a href="sales.php">Sales</a></li>
            <li><a href="history.php">History</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="logout.php?logout=1">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
