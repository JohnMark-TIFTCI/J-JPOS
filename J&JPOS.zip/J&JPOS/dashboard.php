<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Determine if the logged-in user is an admin
$is_admin = ($_SESSION['username'] === 'admin');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <nav>
        <ul>
            <li><a href="sales.php">Sales</a></li>
            <li><a href="history.php">History</a></li>
            <?php if ($is_admin): ?>
                <li><a href="storage.php">Storage</a></li>
                <li><a href="register.php">Register</a></li>
            <?php else: ?>
                <li><a href="view_storage.php">View Storage</a></li>
            <?php endif; ?>
            <li><a href="logout.php?logout=1">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
