<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* Embedded CSS */
        :root {
            --primary-color: #2d3436;
            --secondary-color: #0984e3;
            --background: #f8f9fa;
            --text-color: #2d3436;
        }

        body {
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            background: var(--background);
            color: var(--text-color);
            margin: 0;
            background-color:skyblue;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        h1 {
            text-align: center;
            margin-bottom: 2rem;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .dashboard-card {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
        }

        .dashboard-card h2 {
            margin-bottom: 0.5rem;
        }

        .dashboard-card p {
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome, <?php echo $username; ?>!</h1>
        <div class="dashboard-grid">
            <div class="dashboard-card" onclick="window.location.href='sales.php'">
                <h2>New Sale</h2>
                <p>Start a transaction</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='sales_history.php'">
                <h2>Sales History</h2>
                <p>View past transactions</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='storage.php'">
                <h2>Inventory</h2>
                <p>Manage stock</p>
            </div>
            <div class="dashboard-card" onclick="window.location.href='logout.php'">
                <h2>Logout</h2>
                <p>End your session</p>
            </div>
        </div>
    </div>
</body>
</html>