<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_sale'])) {
    $items = isset($_POST['items']) ? $_POST['items'] : [];
    $quantities = isset($_POST['quantities']) ? $_POST['quantities'] : [];

    if (empty($items) || empty($quantities)) {
        echo "<script>alert('Please select items and quantities');</script>";
    } else {
        $total = 0;
        $sale_items = [];

        foreach ($items as $index => $item_id) {
            $quantity = (int)$quantities[$index];

            $query = "SELECT item_name, price, quantity FROM storage WHERE id = '$item_id'";
            $result = $conn->query($query);

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $item_name = $row['item_name'];
                $item_price = (float)$row['price'];
                $available_quantity = (int)$row['quantity'];

                if ($quantity > $available_quantity) {
                    echo "<script>alert('Insufficient stock for $item_name');</script>";
                } else {
                    $subtotal = $item_price * $quantity;
                    $total += $subtotal;

                    $conn->query("UPDATE storage SET quantity = quantity - $quantity WHERE id = '$item_id'");

                    $sale_items[] = [
                        'item_id' => $item_id,
                        'item_name' => $item_name,
                        'quantity' => $quantity,
                        'subtotal' => $subtotal
                    ];
                }
            }
        }

        if (!empty($sale_items)) {
            $conn->query("INSERT INTO sales (total_amount) VALUES ($total)");
            $sale_id = $conn->insert_id;

            foreach ($sale_items as $sale_item) {
                $conn->query("
                    INSERT INTO sale_items (sale_id, item_id, item_name, quantity, subtotal) 
                    VALUES ('$sale_id', '{$sale_item['item_id']}', '{$sale_item['item_name']}', '{$sale_item['quantity']}', '{$sale_item['subtotal']}')
                ");
            }

            echo "<script>alert('Sale completed! Total: $$total'); window.location.href = 'sales_history.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales</title>
    <style>
        /* Embedded CSS */
        :root {
            --primary-color: #2d3436;
            --secondary-color: #0984e3;
            --background: #f8f9fa;
            --text-color: #2d3436;
        }

        body {
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            background: var(--background);
            color: var(--text-color);
            margin: 0;
            background-color:skyblue;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        h1 {
            text-align: center;
            margin-bottom: 2rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            margin: 2rem 0;
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #dfe6e9;
        }

        th {
            background: var(--primary-color);
            color: white;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        input[type="number"] {
            width: 80px;
            padding: 8px;
            border: 1px solid #dfe6e9;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        input[type="number"]:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 3px rgba(9, 132, 227, 0.1);
        }

        button[type="submit"] {
            background: var(--secondary-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        button[type="submit"]:hover {
            background: #0873c4;
            transform: translateY(-2px);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Complete Sale</h1>
        <form method="POST">
            <table>
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Item Name</th>
                        <th>Price</th>
                        <th>Available Quantity</th>
                        <th>Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM storage";
                    $result = $conn->query($query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><input type="checkbox" name="items[]" value="<?= $row['id']; ?>"></td>
                                <td><?= htmlspecialchars($row['item_name']); ?></td>
                                <td><?= htmlspecialchars($row['price']); ?></td>
                                <td><?= htmlspecialchars($row['quantity']); ?></td>
                                <td><input type="number" name="quantities[]" min="1" max="<?= htmlspecialchars($row['quantity']); ?>" required></td>
                            </tr>
                        <?php endwhile;
                    } else {
                        echo "<tr><td colspan='5'>No items available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <button type="submit" name="submit_sale">Complete Sale</button>
        </form>
    </div>
</body>
</html>