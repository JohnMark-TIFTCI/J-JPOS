<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

if (isset($_GET['sale_id'])) {
    $sale_id = $_GET['sale_id'];
    $sql = "SELECT * FROM sale_items WHERE sale_id = '$sale_id'";
    $result = $conn->query($sql);
    $sale_details = $result->fetch_all(MYSQLI_ASSOC);
    $sale_info = $conn->query("SELECT total_amount, created_at FROM sales WHERE sale_id = '$sale_id'")->fetch_assoc();
} else {
    echo "<script>alert('No sale found.'); window.location.href = 'sales_history.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        :root {
            --primary-color: #2d3436;
            --secondary-color: #0984e3;
            --background: #f8f9fa;
            --text-color: #2d3436;
        }

        body {
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            background: var(--background);
            color: var(--text-color);
            margin: 0;
            background-color:skyblue;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        h1 {
            text-align: center;
            margin-bottom: 2rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            margin: 2rem 0;
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #dfe6e9;
        }

        th {
            background: var(--primary-color);
            color: white;
        }

        a {
            color: var(--secondary-color);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        a:hover {
            text-decoration: underline;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Sale Receipt</h1>
        <p><strong>Date:</strong> <?php echo $sale_info['created_at']; ?></p>
        <p><strong>Total:</strong> $<?php echo $sale_info['total_amount']; ?></p>

        <h2>Sale Items</h2>
        <table>
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php foreach ($sale_details as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td>$<?php echo number_format($item['subtotal'], 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="sales_history.php">Back to Sales History</a>
    </div>
</body>
</html>