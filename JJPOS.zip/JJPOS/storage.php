<?php
session_start();
include('db.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Handle form submission for adding/updating storage
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_storage'])) {
    $item_id = $_POST['item_id'];
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    // Check if item ID already exists with a different name
    $check_sql = "SELECT * FROM storage WHERE item_id = '$item_id'";
    $result = $conn->query($check_sql);

    if ($result && $result->num_rows > 0) {
        $existing_item = $result->fetch_assoc();
        if ($existing_item['item_name'] !== $item_name) {
            echo "<script>alert('Invalid input: Item ID already exists with a different name. Please try again.');</script>";
        } else {
            // Insert or update the item in storage
            $sql = "INSERT INTO storage (item_id, item_name, quantity, price) 
                    VALUES ('$item_id', '$item_name', '$quantity', '$price')
                    ON DUPLICATE KEY UPDATE 
                    quantity = quantity + '$quantity', price = '$price';";

            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Storage updated successfully');</script>";
            } else {
                echo "<script>alert('Error: " . $conn->error . "');</script>";
            }
        }
    } else {
        // Insert the new item if no conflicts
        $sql = "INSERT INTO storage (item_id, item_name, quantity, price) 
                VALUES ('$item_id', '$item_name', '$quantity', '$price')
                ON DUPLICATE KEY UPDATE 
                quantity = quantity + '$quantity', price = '$price';";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Storage updated successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
}

// Handle item deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM storage WHERE item_id = '$delete_id'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Item deleted successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Handle reducing stock
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reduce_stock'])) {
    $reduce_item_id = $_POST['reduce_item_id'];
    $reduce_quantity = $_POST['reduce_quantity'];

    // Check if item exists
    $sql = "SELECT * FROM storage WHERE item_id = '$reduce_item_id'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['quantity'] >= $reduce_quantity) {
            // Reduce the quantity
            $new_quantity = $row['quantity'] - $reduce_quantity;
            $update_sql = "UPDATE storage SET quantity = '$new_quantity' WHERE item_id = '$reduce_item_id'";
            if ($conn->query($update_sql) === TRUE) {
                echo "<script>alert('Stock reduced successfully');</script>";
            } else {
                echo "<script>alert('Error: " . $conn->error . "');</script>";
            }
        } else {
            echo "<script>alert('Error: Not enough stock to reduce');</script>";
        }
    } else {
        echo "<script>alert('Error: Item not found');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <style>
        /* Embedded CSS */
        :root {
            --primary-color: #2d3436;
            --secondary-color: #0984e3;
            --background: #f8f9fa;
            --text-color: #2d3436;
            --error: #d63031;
        }

        body {
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            background: var(--background);
            color: var(--text-color);
            margin: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        h1 {
            text-align: center;
            margin-bottom: 2rem;
        }

        form {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #dfe6e9;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        input:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 3px rgba(9, 132, 227, 0.1);
            outline: none;
        }

        button {
            background: var(--secondary-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            width: 100%;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        button:hover {
            background: #0873c4;
            transform: translateY(-2px);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #dfe6e9;
        }

        th {
            background: var(--primary-color);
            color: white;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        .delete-btn,
        .reduce-btn {
            background: var(--secondary-color);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .delete-btn:hover,
        .reduce-btn:hover {
            background: #0873c4;
            transform: translateY(-2px);
        }
        
        .reduce-form {
            display: none;
            margin-top: 10px;
        }
        
        .reduce-form input {
            width: 80%;
        }

        .reduce-form button {
            width: 20%;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Inventory</h1>

        <!-- Add/Update Form -->
        <form method="POST">
            <input type="text" name="item_id" placeholder="Item ID" required>
            <input type="text" name="item_name" placeholder="Item Name" required>
            <input type="number" name="quantity" placeholder="Quantity" required>
            <input type="number" step="0.01" name="price" placeholder="Price" required>
            <button type="submit" name="update_storage">Add/Update Item</button>
        </form>

        <!-- Inventory Table -->
        <h2>Current Inventory</h2>
        <table>
            <thead>
                <tr>
                    <th>Item ID</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM storage");
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$row['item_id']}</td>";
                        echo "<td>{$row['item_name']}</td>";
                        echo "<td>{$row['quantity']}</td>";
                        echo "<td>{$row['price']}</td>";
                        echo "<td><button class='reduce-btn' onclick=\"showReduceForm('reduce-form-{$row['item_id']}')\">Reduce</button></td>";
                        echo "</tr>";
                        echo "
                        <tr id='reduce-form-{$row['item_id']}' class='reduce-form'>
                            <td colspan='5'>
                                <form method='POST'>
                                    <input type='number' name='reduce_quantity' placeholder='Quantity to reduce' required>
                                    <input type='hidden' name='reduce_item_id' value='{$row['item_id']}'>
                                    <button type='submit' name='reduce_stock'>Reduce Stock</button>
                                </form>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No items available</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        function showReduceForm(formId) {
            const form = document.getElementById(formId);
            form.style.display = form.style.display === "none" ? "table-row" : "none";
        }
    </script>
</body>
</html>
