<?php
session_start();
include('db.php');

// Authentication check
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Validate form submission
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['submit_sale'])) {
    header('Location: sales.php');
    exit;
}

// Initialize transaction
$conn->begin_transaction();

try {
    // Validate items and quantities
    if (empty($_POST['items']) || empty($_POST['quantities'])) {
        throw new Exception("No items selected for purchase");
    }

    $items = $_POST['items'];
    $quantities = $_POST['quantities'];
    $total = 0;
    $sale_items = [];

    // Process each item
    foreach ($items as $item_id) {
        if (!isset($quantities[$item_id]) || $quantities[$item_id] < 1) {
            throw new Exception("Invalid quantity for item $item_id");
        }

        // Get product details
        $stmt = $conn->prepare("SELECT * FROM storage WHERE item_id = ? FOR UPDATE");
        $stmt->bind_param("s", $item_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();

        if (!$product) {
            throw new Exception("Product $item_id not found");
        }

        // Validate stock
        $qty = (int)$quantities[$item_id];
        if ($product['quantity'] < $qty) {
            throw new Exception("Insufficient stock for {$product['item_name']}");
        }

        // Calculate subtotal
        $subtotal = $product['price'] * $qty;
        $total += $subtotal;

        // Store sale item details
        $sale_items[] = [
            'item_id' => $item_id,
            'item_name' => $product['item_name'],
            'qty' => $qty,
            'price' => $product['price'],
            'subtotal' => $subtotal
        ];
    }

    // Create sale record
    $stmt = $conn->prepare("INSERT INTO sales (total_amount, cashier) VALUES (?, ?)");
    $stmt->bind_param("ds", $total, $_SESSION['username']);
    $stmt->execute();
    $sale_id = $conn->insert_id;

    // Create sale items
    $stmt = $conn->prepare("INSERT INTO sale_items 
        (sale_id, item_id, item_name, quantity, price, subtotal)
        VALUES (?, ?, ?, ?, ?, ?)");

    foreach ($sale_items as $item) {
        $stmt->bind_param("issidd", 
            $sale_id,
            $item['item_id'],
            $item['item_name'],
            $item['qty'],
            $item['price'],
            $item['subtotal']
        );
        $stmt->execute();
    }

    // Update inventory
    foreach ($sale_items as $item) {
        $stmt = $conn->prepare("UPDATE storage SET quantity = quantity - ? WHERE item_id = ?");
        $stmt->bind_param("is", $item['qty'], $item['item_id']);
        $stmt->execute();
    }

    // Commit transaction
    $conn->commit();

} catch (Exception $e) {
    $conn->rollback();
    die("Error processing sale: " . $e->getMessage());
}

// Display receipt
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sale Receipt</title>
    <style>
        .receipt { width: 300px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; }
        .receipt-table { width: 100%; margin: 15px 0; }
        .center { text-align: center; }
    </style>
</head>
<body>
    <div class="receipt">
        <h2 class="center">Sales Receipt</h2>
        <p>Date: <?= date('Y-m-d H:i:s') ?></p>
        <p>Cashier: <?= htmlspecialchars($_SESSION['username']) ?></p>
        
        <table class="receipt-table">
            <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
            <?php foreach ($sale_items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['item_name']) ?></td>
                <td><?= $item['qty'] ?></td>
                <td>$<?= number_format($item['price'], 2) ?></td>
                <td>$<?= number_format($item['subtotal'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        
        <h3 class="center">Total: $<?= number_format($total, 2) ?></h3>
        <button onclick="window.print()">Print Receipt</button>
        <a href="sales.php"><button>New Sale</button></a>
    </div>
</body>
</html>