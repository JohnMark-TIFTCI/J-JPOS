<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Handle add/update item
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_storage'])) {
    $item_id = $_POST['item_id'];
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $check_sql = "SELECT * FROM storage WHERE item_id = '$item_id'";
    $result = $conn->query($check_sql);

    if ($result && $result->num_rows > 0) {
        $existing_item = $result->fetch_assoc();
        if ($existing_item['item_name'] !== $item_name || floatval($existing_item['price']) != floatval($price)) {
            echo "<script>alert('Invalid input: Item ID must match the name and price.');</script>";
        } else {
            $sql = "UPDATE storage SET quantity = quantity + $quantity WHERE item_id = '$item_id'";
            if ($conn->query($sql)) {
                echo "<script>alert('Storage updated successfully'); window.location.href='storage.php';</script>";
                exit;
            } else {
                echo "<script>alert('Error: " . $conn->error . "');</script>";
            }
        }
    } else {
        $sql = "INSERT INTO storage (item_id, item_name, quantity, price) VALUES ('$item_id', '$item_name', $quantity, $price)";
        if ($conn->query($sql)) {
            echo "<script>alert('New item added'); window.location.href='storage.php';</script>";
            exit;
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
}

// Handle reduce stock
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reduce_stock'])) {
    $item_id = $_POST['reduce_item_id'];
    $reduce_quantity = $_POST['reduce_quantity'];

    $sql = "UPDATE storage SET quantity = quantity - $reduce_quantity WHERE item_id = '$item_id' AND quantity >= $reduce_quantity";
    if ($conn->query($sql)) {
        echo "<script>alert('Stock reduced successfully'); window.location.href='storage.php';</script>";
        exit;
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <style>
        :root {
            --primary: #2A3950;
            --secondary: #3D5A80;
            --accent: #4F88C6;
            --background: #F5F7FA;
            --text: #2A2D34;
        }
        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background: var(--background);
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: var(--primary);
            color: white;
            padding: 2rem 1rem;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }
        .main-content {
            flex: 1;
            padding: 2rem;
        }
        h1, h2 {
            color: var(--text);
        }
        form input, form button {
            margin: 0.5rem 0;
            padding: 0.5rem;
            font-size: 1rem;
        }
        form button {
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        th, td {
            padding: 1rem;
            border-bottom: 1px solid #eee;
            text-align: left;
        }
        th {
            background: var(--secondary);
            color: white;
        }
        .reduce-form {
            display: none;
        }
        .btn-reduce {
            background: #e74c3c;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>JJ POS System</h2>
        <div class="nav-item" onclick="location.href='dashboard.php'">Dashboard</div>
        <div class="nav-item" onclick="location.href='sales_history.php'">Sales History</div>
        <div class="nav-item" onclick="location.href='storage.php'">Inventory</div>
        <div class="nav-item" onclick="location.href='logout.php'">Logout</div>
    </div>

    <div class="main-content">
        <h1>Inventory Management</h1>
        <form method="POST">
            <input type="text" name="item_id" placeholder="Item ID" required>
            <input type="text" name="item_name" placeholder="Item Name" required>
            <input type="number" name="quantity" placeholder="Quantity" required>
            <input type="number" step="0.01" name="price" placeholder="Price" required>
            <button type="submit" name="update_storage">Add/Update Item</button>
        </form>

        <h2>Current Inventory</h2>
        <table>
            <thead>
                <tr>
                    <th>Item ID</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM storage");
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$row['item_id']}</td>";
                        echo "<td>{$row['item_name']}</td>";
                        echo "<td>{$row['quantity']}</td>";
                        echo "<td>$" . number_format((float)$row['price'], 2) . "</td>";
                        echo "<td><button class='btn-reduce' onclick=\"toggleForm('form-{$row['item_id']}')\">Reduce</button></td>";
                        echo "</tr>";
                        echo "<tr id='form-{$row['item_id']}' class='reduce-form'><td colspan='5'>
                                <form method='POST'>
                                    <input type='hidden' name='reduce_item_id' value='{$row['item_id']}'>
                                    <input type='number' name='reduce_quantity' placeholder='Quantity to reduce' required>
                                    <button type='submit' name='reduce_stock'>Confirm</button>
                                </form>
                              </td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No items found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        function toggleForm(id) {
            const form = document.getElementById(id);
            if (form) {
                form.style.display = form.style.display === 'table-row' ? 'none' : 'table-row';
            }
        }
    </script>
</body>
</html>