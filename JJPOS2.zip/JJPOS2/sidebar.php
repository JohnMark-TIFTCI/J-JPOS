<?php
// sidebar.php
// — remove session_start() here! —

// You can still include the DB connection if you need it:
include 'db.php';
?>
<div class="sidebar">
    <h2>JJ POS System</h2>
    <div class="nav-item" onclick="location.href='dashboard.php'">
        <i class="fas fa-home"></i> Dashboard
    </div>
    <div class="nav-item" onclick="location.href='sales.php'">
        <i class="fas fa-cash-register"></i> New Sale
    </div>
    <div class="nav-item" onclick="location.href='sales_history.php'">
        <i class="fas fa-history"></i> Sales History
    </div>
    <div class="nav-item" onclick="location.href='storage.php'">
        <i class="fas fa-boxes"></i> Inventory
    </div>
    <div class="nav-item" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </div>
</div>
