<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

// Validate sale_id exists
if (!isset($_GET['sale_id'])) {
    die("Invalid request - Missing sale ID");
}

$sale_id = (int)$_GET['sale_id'];

// Fetch sale information
$sale_info = [];
$sale_details = [];

try {
    // Get main sale info
    $stmt = $conn->prepare("SELECT total_amount, created_at FROM sales WHERE sale_id = ?");
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $sale_info = $stmt->get_result()->fetch_assoc();
    
    if (!$sale_info) {
        throw new Exception("Sale record not found");
    }

    // Get sale items
    $stmt = $conn->prepare("SELECT item_name, quantity, subtotal FROM sale_items WHERE sale_id = ?");
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $sale_details = $result->fetch_all(MYSQLI_ASSOC);

} catch (Exception $e) {
    die("Error retrieving sale data: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Receipt</title>
    <style>
        @media print {
            body * { visibility: hidden; }
            .receipt, .receipt * { visibility: visible; }
            .receipt { position: absolute; left: 0; top: 0; }
        }

        body {
            background: #fff;
            font-family: 'Courier New', monospace;
            display: flex;
            justify-content: center;
            padding: 2rem;
        }

        .receipt {
            width: 300px;
            padding: 20px;
            background: #fff;
            border: 2px dashed #ccc;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 1rem;
            border-bottom: 2px dashed #000;
            padding-bottom: 1rem;
        }

        .company-name {
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .receipt-info {
            display: flex;
            justify-content: space-between;
            margin: 1rem 0;
            font-size: 0.9rem;
        }

        .items-table {
            width: 100%;
            margin: 1rem 0;
            border-collapse: collapse;
        }

        .items-table td {
            padding: 0.3rem 0;
            border-bottom: 1px dashed #ddd;
        }

        .total-section {
            text-align: right;
            margin: 1rem 0;
            font-weight: bold;
            font-size: 1.1rem;
        }

        .footer {
            text-align: center;
            font-size: 0.8rem;
            margin-top: 2rem;
            color: #666;
        }

        .barcode {
            text-align: center;
            margin: 1rem 0;
            padding: 10px;
            border-top: 1px dashed #000;
            font-family: 'Libre Barcode 39', cursive;
            font-size: 2rem;
        }
    </style>
</head>
<body>
    <div class="receipt">
        <div class="header">
            <div class="company-name">JJ POS STORE</div>
            <div>123 Business Street</div>
            <div>New York, NY 10001</div>
            <div>Tel: (555) 123-4567</div>
        </div>

        <div class="receipt-info">
            <div>Receipt #: <?= $sale_id ?></div>
            <div><?= date('m/d/Y H:i', strtotime($sale_info['created_at'])) ?></div>
        </div>

        <table class="items-table">
            <?php foreach ($sale_details as $item): ?>
            <tr>
                <td><?= $item['quantity'] ?> x <?= htmlspecialchars($item['item_name']) ?></td>
                <td style="text-align: right">$<?= number_format($item['subtotal'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>

        <div class="total-section">
            TOTAL: $<?= number_format($sale_info['total_amount'], 2) ?>
        </div>

        <div class="barcode">
            *<?= $sale_id ?>*
        </div>

        <div class="footer">
            Thank you for your business!<br>
            <?= date('M d, Y') ?> | <?= htmlspecialchars($_SESSION['username']) ?><br>
            <small>Items cannot be returned without receipt</small>
        </div>
    </div>

    <script>
        window.onload = function() {
            window.print();
            setTimeout(function() {
                window.location.href = 'sales_history.php';
            }, 1000);
        }
    </script>
</body>
</html>