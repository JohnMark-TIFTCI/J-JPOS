<?php
// sales.php
session_start();
include('db.php');
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Sale</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>
    <div class="main-content">
        <h1>New Transaction</h1>
        <form method="POST" action="complete_sale.php">
            <table>
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Qty</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $stmt = $conn->prepare("SELECT item_id, item_name, price, quantity FROM storage");
                $stmt->execute();
                $res = $stmt->get_result();
                while ($row = $res->fetch_assoc()):
                    $id = htmlspecialchars($row['item_id']);
                ?>
                    <tr>
                        <td><input type="checkbox" name="items[]" value="<?= $id ?>" onchange="toggleQty(this)"></td>
                        <td><?= htmlspecialchars($row['item_name']) ?></td>
                        <td>$<?= number_format($row['price'], 2) ?></td>
                        <td><?= (int)$row['quantity'] ?></td>
                        <td><input type="number" name="quantities[<?= $id ?>]" min="1" max="<?= (int)$row['quantity'] ?>" value="1" disabled></td>
                    </tr>
                <?php endwhile; $stmt->close(); ?>
                </tbody>
            </table>
            <button type="submit" name="submit_sale" class="btn-primary">Complete Sale</button>
        </form>
    </div>

    <script>
    function toggleQty(cb) {
        const qty = cb.closest('tr').querySelector('input[type=number]');
        qty.disabled = !cb.checked;
    }
    </script>
</body>
</html>