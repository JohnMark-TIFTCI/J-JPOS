<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Groceries Sales and Inventory System</title>

  <?php include('./header.php'); ?>
  <?php include('./db_connect.php'); ?>
  <?php 
  session_start();
  if(isset($_SESSION['login_id']))
  header("location:index.php?page=home");

  $query = $conn->query("SELECT * FROM system_settings LIMIT 1")->fetch_array();
  foreach ($query as $key => $value) {
      if(!is_numeric($key))
          $_SESSION['setting_'.$key] = $value;
  }
  ?>

  <style>
    body {
        width: 100%;
        height: 100vh;
        background: url('picture/2.jpg') no-repeat center center;
        background-size: cover;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .login-container {
        width: 30%;
        background: rgba(255, 255, 255, 0.8);
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
    }
    
    .login-container .form-group {
        margin-bottom: 15px;
    }
    
    .login-container button {
        width: 100%;
    }
  </style>
</head>

<body>

  <div class="login-container">
    <h3 class="text-center">Admin Login</h3>
    <form id="login-form">
      <div class="form-group">
        <label for="username" class="control-label">Username</label>
        <input type="text" id="username" name="username" class="form-control">
      </div>
      <div class="form-group">
        <label for="password" class="control-label">Password</label>
        <input type="password" id="password" name="password" class="form-control">
      </div>
      <button class="btn btn-primary">Login</button>
    </form>
  </div>

  <script>
    $('#login-form').submit(function(e){
        e.preventDefault();
        $('button').attr('disabled', true).html('Logging in...');
        $('.alert-danger').remove();
        
        $.ajax({
            url: 'ajax.php?action=login',
            method: 'POST',
            data: $(this).serialize(),
            error: err => {
                console.log(err);
                $('button').removeAttr('disabled').html('Login');
            },
            success: function(resp){
                if(resp == 1){
                    location.href = 'index.php?page=home';
                } else if(resp == 2){
                    location.href = 'voting.php';
                } else {
                    $('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>');
                    $('button').removeAttr('disabled').html('Login');
                }
            }
        });
    });
  </script>

</body>
</html>
