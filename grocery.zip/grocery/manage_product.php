<?php include('db_connect.php');
$sku = mt_rand(1,99999999);
$sku = sprintf("%'.08d\n", $sku);
// ... existing SKU generation code ...
?>

<div class="container-fluid">
    <div class="col-lg-12">
        <div class="row">
            <!-- Product Form Panel -->
            <div class="col-md-4">
                <form action="" id="manage-product">
                    <div class="card">
                        <div class="card-header">
                            <h4>Product Form</h4>
                        </div>
                        <div class="card-body">
                            <input type="hidden" name="id">
                            <div class="form-group">
                                <label>SKU</label>
                                <input type="text" class="form-control" name="sku" value="<?php echo $sku ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label>Category</label>
                                <select name="category_id" class="form-control select2" required>
                                    <?php 
                                    $cat = $conn->query("SELECT * FROM category_list");
                                    while($row = $cat->fetch_assoc()):
                                    ?>
                                    <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Product Name</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" name="description" required></textarea>
                            </div>
                            <div class="form-group">
                                <label>Price</label>
                                <input type="number" step="0.01" class="form-control" name="price" required>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save Product</button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Product List -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>SKU</th>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $products = $conn->query("SELECT p.*, c.name as category 
                                                        FROM product_list p
                                                        JOIN category_list c ON p.category_id = c.id");
                                while($row = $products->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $row['sku'] ?></td>
                                    <td><?php echo $row['name'] ?></td>
                                    <td><?php echo $row['category'] ?></td>
                                    <td><?php echo number_format($row['price'], 2) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-product" 
                                                data-id="<?php echo $row['id'] ?>"
                                                data-sku="<?php echo $row['sku'] ?>"
                                                data-name="<?php echo $row['name'] ?>"
                                                data-description="<?php echo $row['description'] ?>"
                                                data-price="<?php echo $row['price'] ?>"
                                                data-category="<?php echo $row['category_id'] ?>">
                                            Edit
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-product" 
                                                data-id="<?php echo $row['id'] ?>">
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Initialize DataTable
    $('table').DataTable();
    
    // Form submission handler
    $('#manage-product').submit(function(e) {
        e.preventDefault();
        start_load();
        $.ajax({
            url: 'ajax.php?action=save_product',
            method: 'POST',
            data: $(this).serialize(),
            success: function(resp) {
                if(resp == 1) {
                    alert_toast("Product saved successfully", 'success');
                    setTimeout(() => location.reload(), 1500);
                } else if(resp == 2) {
                    alert_toast("Product updated successfully", 'success');
                    setTimeout(() => location.reload(), 1500);
                }
            },
            error: function() {
                alert_toast("An error occurred", 'danger');
                end_load();
            }
        });
    });

    // Edit product handler
    $('.edit-product').click(function() {
        const product = $(this).data();
        $('[name="id"]').val(product.id);
        $('[name="sku"]').val(product.sku);
        $('[name="name"]').val(product.name);
        $('[name="description"]').val(product.description);
        $('[name="price"]').val(product.price);
        $('[name="category_id"]').val(product.category).trigger('change');
    });

    // Delete product handler
    $('.delete-product').click(function() {
        const id = $(this).data('id');
        _conf("Delete this product?", 'delete_product', [id]);
    });
});

function delete_product(id) {
    start_load();
    $.ajax({
        url: 'ajax.php?action=delete_product',
        method: 'POST',
        data: { id: id },
        success: function(resp) {
            if(resp == 1) {
                alert_toast("Product deleted", 'success');
                setTimeout(() => location.reload(), 1500);
            }
        }
    });
}
</script>